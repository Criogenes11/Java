import java.util.*;
import java.io.*;




public class rondo {
	 
	public static void main(String[]args)
		{
	        try
	        {

	        
	         String in_Stream = ("..\\input\\");
	         String out_Stream = ("..\\output\\");
	         String fileName_cvs = in_Stream + "wolf_creek_hourly_2019_01.csv";
	         String fileName_html = out_Stream + "2019_01.html";
	         File file = new File (fileName_html);
	         BufferedReader br = new BufferedReader(new FileReader(fileName_cvs));
	         Scanner scan = new Scanner (br);
	         BufferedWriter bw = new BufferedWriter(new FileWriter(file));
	         
	         bw.write("<!DOCTYPE HTML>\n");
			 bw.write("<html dir=\"ltr\" lang=\"en\">\n");
			 bw.write("<head>\n");
			 bw.write("\n");
			 bw.write("\t<meta charset=\"utf-8\">\n");
			 bw.write("\t<title>Wolf Creek Dam : 2019-01</title>\n");
			 bw.write("\n");
			 bw.write("\t<style>\n");
			 bw.write("\t\ttable,th,td {\n");
			 bw.write("\t\t\tborder:1px solid black;\n");
			 bw.write("\t\t\tborder-collapse:collapse;\n");
			 bw.write("\t\t\tpadding:10px;\n");
			 bw.write("\t\t\ttext-align:right;\n");
			 bw.write("\t\t}\n");
			 bw.write("\t</style>\n");
			 bw.write("\n");
			 bw.write("</head>\n");
			 bw.write("<body>\n");
			 bw.write("\n");
			 bw.write("\t<div id=\"month_01\" class=\"month_rows\">\n");
			 bw.write("\t<h2 class=\"major_format\">Gage Readings for 2019-01:</h2>\n");
			 bw.write("\t<table class=\"hrly_readings\">\n");
			 bw.write("\t\t<thead>\n");
			 bw.write("\t\t\t<tr>\n");
			 bw.write("\t\t\t\t<th>GAGE TIME<br>UTC (ISO-8601):</th>\n");
			 bw.write("\t\t\t\t<th>ELEVATION<br>UPSTREAM:</th>\n");
			 bw.write("\t\t\t\t<th>ELEVATION<br>DOWNSTREAM:</th>\n");
			 bw.write("\t\t\t\t<th>DISCHARGE<br>HOURLY AVG.:</th>\n");
			 bw.write("\t\t\t</tr>\n");
			 bw.write("\t\t</thead>\n");
			 bw.write("\t\t<tbody>\n");
	         
	         while ( scan.hasNextLine() )  
	            { 
	                String line = scan.nextLine().replace("\"", "");
	                String[] fields = line.split(",");
	                bw.write("\t\t\t<tr>");
	                for (int j=0; j<4; j++) 
	                {
	                    bw.write("\t<td>" + fields[j] + "</td>");
	                }						
	                bw.write("\t</tr>\n");
	            }

	            bw.write("\t\t</tbody>\n");
				bw.write("\t</table>\n");
				bw.write("	</div> <div id=\"month_01\" class=\"month_rows\"> \n");
				bw.write("\n");
				bw.write("</body>\n");
				bw.write("</html>");
	            bw.close();
	            scan.close();
	        }catch(FileNotFoundException E)
			{
				System.out.println("File was not found.");
			}catch(IOException E)
			{
				System.out.println("Something unexpected occured");
			}
			
	    }
	}

